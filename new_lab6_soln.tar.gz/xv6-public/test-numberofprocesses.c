// // #include "types.h"
// // #include "stat.h"
// // #include "user.h"

// // int main(int argc, char *argv[])
// // {

// //     printf(1, "Total Number of Ready Processes before fork: %d\n", numberofprocesses());

// //     for(int i=0;i<5;i++)
// //     {
// //         int id=fork();
// //         if(id==0)
// //         {
// //             printf(1, "Total Number of Ready Processes After %d forks: %d\n", i+1,numberofprocesses());

// //             exit();
// //         }
// //     }
// //     for(int i=0;i<5;i++)
// //         wait();

// //     exit();
// // }

// #include "types.h"
// #include "stat.h"
// #include "user.h"



// int main(void)
// {

//     int pid1 = fork();
//     if (pid1 == 0)
//     {
//         // Child process 1

//         int i;
//         int a=0;
//         for (i = 0; i < 1000; i++)
//         {
            
//             a=a+2*i+2*a;
            
//         }
        
//         exit();
//     }

//     int pid2 = fork();
//     if (pid2 == 0)
//     {
//         // Child process 2
//         int i,j,k,l;
//         int a=0;
//         for (i = 0; i < 1000000000; i++)
//         {
//             for (j = 0; j < 1000000000; j++)
//             {
//                 for(k=0;k<1000000000;k++)
//                 {
//                     for(l=0;l<1000000000;l++)
//                     {
//                         a=a+2*i+2*a+2*j+2*k;
//                     }

//                 }
            
//             }
            
//         }
//         exit();
//     }

//     // Parent process
//     int num_processes_before = numberofprocesses();
//     printf(1, "ready processes: %d\n", num_processes_before);


//     wait(); // Wait for child 1
//     int num_processes_after_wait1 = numberofprocesses();
//     printf(1, "ready processes: %d\n", num_processes_after_wait1);

    
//     wait(); // Wait for child 2
//     int num_processes_after_wait2 = numberofprocesses();
//     printf(1, "ready processes: %d\n", num_processes_after_wait2);



//     exit();
// }
// #include "types.h"
// #include "stat.h"
// #include "user.h"

// int main(int argc, char *argv[])
// {

//     printf(1, "Total Number of Ready Processes before fork: %d\n", numberofprocesses());

//     for(int i=0;i<5;i++)
//     {
//         int id=fork();
//         if(id==0)
//         {
//             printf(1, "Total Number of Ready Processes After %d forks: %d\n", i+1,numberofprocesses());

//             exit();
//         }
//     }
//     for(int i=0;i<5;i++)
//         wait();

//     exit();
// }

#include "types.h"
#include "stat.h"
#include "user.h"

#define SHORT_LOOP 100
#define LONG_LOOP  1000

void busy_loop1(int n)
{
    int i;
    for (i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
         {
    	    int*a =malloc(sizeof(int));
            *a=i*j;
            free(a);
         } // Simulate some busy work
    }
}

void busy_loop2(int n)
{
    int i;
    for (i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
         {
    	    int*a =malloc(sizeof(int));
            *a=i*j;
            free(a);
         } // Simulate some busy work
    }
}

int main(void) {
    int pid1 = fork();
    if (pid1 == 0)
    {
        // Child process 1

        busy_loop1(SHORT_LOOP); 
        exit();
    }
    else if(fork()==0)
    {
        // Child process 2
        busy_loop2(LONG_LOOP); 
        exit();
    }

    // Parent process
    int n1 = numberofprocesses();

    wait(); // Wait for child 1
    int n2 = numberofprocesses();

    wait(); // Wait for child 2
    int n3= numberofprocesses();

    printf(1, "ready processes: %d\n", n1);
    printf(1, "ready processes: %d\n", n2);
    printf(1, "ready processes: %d\n", n3);



    exit();
}







