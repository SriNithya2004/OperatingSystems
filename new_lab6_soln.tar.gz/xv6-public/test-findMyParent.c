#include "types.h"

#include "stat.h"

#include "user.h"

 

int main(int argc, char *argv[])

{

    int pid = getpid();

    printf(1,"My process id is %d\n",pid);

 
    int ppid = findMyParent(pid);

    if(ppid==-1){
        printf(1,"Current process pid is not found in ptable\n");
    }

    printf(1,"My parent process id is %d\n",ppid);

    exit();
   
}