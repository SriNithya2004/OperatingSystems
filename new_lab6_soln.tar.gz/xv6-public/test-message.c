#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char* argv[])
{

    // make the message() system call
    
    message();
    exit();
}