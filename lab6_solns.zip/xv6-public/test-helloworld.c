#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char* argv[]){
    
    helloYou("Welcome to xv6\n");
    helloYou("This is a simple task to understand how to add a system call\n");
    exit();
}