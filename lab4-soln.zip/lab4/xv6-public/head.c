#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

void cat(int fd, int num_lines)
{
  int n;
  int lines_printed = 0;

  while ((n = read(fd, buf, sizeof(buf))) > 0)
  {
    for (int i = 0; i < n; i++)
    {
      if (write(1, buf + i, 1) != 1) 
      {
        printf(1, "print_lines: write error\n");
        exit();
      }
      if (buf[i] == '\n') 
      {
        lines_printed++;
        if (lines_printed == num_lines) 
        {
          return;
        }
      }
    }
  }
  if (n < 0) 
  {
    printf(1, "print_lines: read error\n");
    exit();
  }
}

int
main(int argc, char *argv[])
{
  int num_lines, fd, i;

  if (argc <= 2) {
    printf(1, "Usage: %s <num_lines> <file1> [<file2> ...]\n", argv[0]);
    exit();
  }

  num_lines = atoi(argv[1]);

  for (i = 2; i < argc; i++) 
  {
    if ((fd = open(argv[i], 0)) < 0) {
      printf(1, "%s: cannot open %s\n", argv[0], argv[i]);
      continue;  // Move to the next file if this one can't be opened
    }
    printf(1,"------------ %s-------------\n",argv[i]);

    cat(fd, num_lines);
    close(fd);
  }
  exit();
}
