#include <unistd.h>
#include <fcntl.h>
int main(){
    // int open (const char* Path, int flags);
    int open_read=open("in.txt",O_RDONLY);
    if (open_read == -1) {
        perror("Failed to open the file");
        return 1;
    }
    int open_write=open("out.txt",O_WRONLY);
    if (open_write == -1) {
        perror("Failed to open the file");
        return 1;
    }

    
    char character;
    
    while(1){
        // size_t read (int fd, void* buf, size_t cnt);
        size_t reading = read (open_read, &character, sizeof(char));
        if(reading==-1){
            perror("Error / signal interrupt");
            return 1;
        }
        else if(reading==0){
            perror("End of the file");
            break;
            return 1;
        }
        // size_t write (int fd, void* buf, size_t cnt); 
        else{
            size_t writing = write (open_write, &character, reading);
            if(writing==-1){
                perror("Error / signal interrupt");
                return 1;
            }
            else if(writing==0){
                perror("End of the file");
                break;
                return 1;
            }
        }
         
    }
    close(open_read);
    close(open_write);


    return 0;
}
