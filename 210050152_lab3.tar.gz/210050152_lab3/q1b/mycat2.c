#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
int main(){

    while(1){
        char inputt[1024];
        // scanf("%s",&inputt);
        size_t reading = read(0,inputt,sizeof(inputt));
        if(reading==-1){
            perror("Error / signal interrupt");
            return 1;
        }
        else if(reading==0){
            perror("End of the file");
            break;
            return 1;
        }
        else{
            // size_t filedec2;
            size_t writing = write (1, inputt, reading);
            if(writing==-1){
                perror("Error / signal interrupt");
                return 1;
            }
            // else if(writing==0){
            //     perror("End of the file");
            //     break;
            //     return 1;
            // }
            
        }
    }
    return 0;
    
}