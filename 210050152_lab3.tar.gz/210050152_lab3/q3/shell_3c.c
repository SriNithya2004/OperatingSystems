#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define MAX_INPUT_SIZE 1024
#define MAX_TOKEN_SIZE 64
#define MAX_NUM_TOKENS 64

void handle_sigint(int signal_num) {
    printf("\nRECEIVED SIGNAL: %d\n$ ", signal_num);
    fflush(stdout);
}

void handle_sigterm(int signal_num) {
    printf("\nExiting via SIGTERM\n");
    exit(EXIT_SUCCESS);
}

char **tokenize(char *line)
{
	char **tokens = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
	char *token = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
	int i, tokenIndex = 0, tokenNo = 0;

	for (i = 0; i < strlen(line); i++)
	{

		char readChar = line[i];

		if (readChar == ' ' || readChar == '\n' || readChar == '\t')
		{
			token[tokenIndex] = '\0';
			if (tokenIndex != 0)
			{
				tokens[tokenNo] = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
				strcpy(tokens[tokenNo++], token);
				tokenIndex = 0;
			}
		}
		else
		{
			token[tokenIndex++] = readChar;
		}
	}

	free(token);
	tokens[tokenNo] = NULL;
	return tokens;
}

int main(int argc, char *argv[]) {
    char line[MAX_INPUT_SIZE];
    char **tokens;
    int i;

    signal(SIGINT, handle_sigint);
    signal(SIGTERM, handle_sigterm);
    while (1) {
        bzero(line, sizeof(line));
        printf("$ ");
        scanf("%[^\n]", line);
        getchar();

        line[strlen(line)] = '\n';
        tokens = tokenize(line);

        if (tokens[0] == NULL)
            continue;

        if (strcmp(tokens[0], "exit") == 0) {
            kill(getpid(), SIGTERM);
        }

        pid_t pid = fork();
        if (pid == 0) {
            execvp(tokens[0], tokens);
            perror("Error executing command");
            exit(EXIT_FAILURE);
        } else if (pid > 0) {
            int status;
            waitpid(pid, &status, 0);
            for (i = 0; tokens[i] != NULL; i++) {
                free(tokens[i]);
            }
            free(tokens);
        } else {
            perror("Error creating child process");
            return 1;
        }
    }
    return 0;
}
