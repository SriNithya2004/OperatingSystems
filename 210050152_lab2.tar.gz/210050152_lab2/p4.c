#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#define sizee 16
int main(){
    int P[2];

    if(pipe(P)<0){
        exit(1);
    }

    int a;//(x)
    printf("process A : Input value of x : ");
    scanf("%d",&a);
    //writing x into the pipe
    write(P[1],&a,sizeof(a));

    int b;//(y)

    int sum=0,ans=0;

    int f=fork();
    int r;
    if(f<0){
        exit(1);
    }
    else if(f==0){
        printf("process B : Input value of y : ");
        scanf("%d",&b);
        //writing y into the pipe
        write(P[1],&b,sizeof(b));
    }
    else{
        wait(NULL);
        if(r=read(P[0],&sum,sizeof(sum))>0){
            ans=ans+sum; 
            // printf("%d %d \n",sum, ans);
        }
        if(r=read(P[0],&sum,sizeof(sum))>0){
            ans=ans+sum;
            // printf("%d %d\n",sum, ans);
        }
        
        printf("process A : Result after addition : ");
        printf("%d \n",ans );
        // printf("%d %d %d",a,b,sum);
    }
    return 0;
}