#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#define input_length 100
int main(){

    while(1){
        printf(">>>");
        char input[input_length];
        scanf("%s", input);
        
        int pid=fork();

        if(pid<0){
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if(pid==0){
            
            char*args[]={input,NULL};
            // printf("child process \n");
            execvp(args[0],args);
            
        }
        else{
            wait(NULL);
            // printf("parent process \n");
            
        }
    }
    return 0;
}