#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[]) {
    
    int rc = fork();
    if (rc < 0) {
        fprintf(stderr, "fork failed\n");
        exit(1);
    } 
    else if (rc == 0) {
        printf("Child : My process ID is:%d\n", (int) getpid());
        printf("Child : The parent process ID is:%d\n", getppid());
        // wait(NULL);
    } else {
        printf("Parent : My process ID is:%d\n", (int) getpid());
        printf("Parent : The child process ID is:%d\n", rc);
        wait(NULL);
    }
    return 0;
}