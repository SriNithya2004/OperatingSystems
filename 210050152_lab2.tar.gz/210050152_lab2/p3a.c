#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    
    printf("Print statement before exec\n");
    
    // Do exec here

    char *args[]={"./helloworld",NULL};
    // char *args[]={"./byeworld",NULL};
    execvp(args[0],args);
    
    printf("Print statement after exec. This should never print\n");
    
    
    return 0;
}