/*
Write a program p2a.c 
It takes an integer n from the console and prints the process pid and numbers from 1 to 2*n in any order
such that :
the child prints its pid and the numbers from 1 to n  and parent prints its pid and numbers from n+1 to 2*n .
Input : 3
Desired Sample output :
3451 1
3451 2
3448 4
3451 3
3448 5
3448 6   
*/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    int n ;
    printf("n: ");
    scanf("%d",&n);

    // write your code here
    int rc = fork();
    int i;
    if (rc < 0) {
        fprintf(stderr, "fork failed\n");
        exit(1);
    } 
    else if (rc == 0) {
        
        for(i=1;i<=n;i++){
            // int k=getpid();
            printf("C %d %d\n", (int) getpid(),i);
            // waitpid(-1, &k,0);
        }
    } else {
        for(i=n+1;i<=2*n;i++){
            wait(NULL);
            printf("P %d %d\n", (int) getpid(),i);
            // waitpid(-1, &k,0);
        }
    }
    return 0;
}