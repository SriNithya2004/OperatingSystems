#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
int main(){
    int f=fork();
    if(f<0){

        exit(1);
    }
    else if(f==0){
        printf("Child: My processID is : %d\n",getpid());
        printf("Child: The parent processID is : %d\n",getppid());
        printf("I'm sleeping \n");
        sleep(5);
        printf("Child: My processID is : %d\n",getpid());
        printf("Child: The parent processID is : %d\n",getppid());
    }
    else{
        
        printf("Parent: My processID is : %d\n",getpid());
        printf("Parent: The child processID is : %d\n",f);
        sleep(1);

        // exit();
    }
    return 0;
}