#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    
    printf("Print statement before exec\n");
    
    // Do exec here
    

    printf("Print statement after exec. This should never print\n");
    
    
    return 0;
}